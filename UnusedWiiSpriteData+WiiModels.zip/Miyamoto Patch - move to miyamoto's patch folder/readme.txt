# MiyamotoUnusedWiiSpritedata
[Miyamoto! Level Editor](https://github.com/aboood40091/Miyamoto) patch that has the spritedata for the most of the unused Wii sprites

So far there is only spritedata the following sprites:
- Sprite 319 (Move-when-on Metal Block [UNUSED])

There aren't any sprite images at the moment, but I plan to add some later.

# Usage

Add the `UnusedWiiSpritedata` folder to the miyamotodata/patches folder, then change the game to Unused Wii Actor Spritedata in Miyamoto.

Check the release notes for the actor resources to use ingame.

Release notes: https://github.com/techmuse8/MiyamotoUnusedWiiSpritedata/releases

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

UPDATE!!! Domthewiz has added the spritedata for sprites 360 and 358
Also added images for most of the fixable sprites.